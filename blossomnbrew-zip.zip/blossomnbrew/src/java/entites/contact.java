package entites;

public class contact
{
    private int fid;
    private String fname;
    private String femail;
    private String fmess;

    public contact(int fid, String fname, String femail, String fmess) {
        this.fid = fid;
        this.fname = fname;
        this.femail = femail;
        this.fmess = fmess;
    }

    public contact() {
    }

    public int getFid() {
        return fid;
    }

    public void setFid(int fid) {
        this.fid = fid;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getFemail() {
        return femail;
    }

    public void setFemail(String femail) {
        this.femail = femail;
    }

    public String getFmess() {
        return fmess;
    }

    public void setFmess(String fmess) {
        this.fmess = fmess;
    }
    
    
}
