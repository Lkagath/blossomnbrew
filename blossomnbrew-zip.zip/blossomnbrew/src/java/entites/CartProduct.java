/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

 public class CartProduct {
    private int pid;
    private String pname;
    private String pimage;
    private int pprice;
    private int quantity;

    // Constructor, getters, and setters
    public CartProduct(int pid, String pname, String pimage, int pprice, int quantity) {
        this.pid = pid;
        this.pname = pname;
        this.pimage=pimage;
        this.pprice = pprice;
        this.quantity = quantity;
    }


    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public int getPprice() {
        return pprice;
    }

    public void setPprice(int pprice) {
        this.pprice = pprice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getPimage() {
        return pimage;
    }

    public void setPimage(String pimage) {
        this.pimage = pimage;
    }
    
    
}
