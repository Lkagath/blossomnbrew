package entites;
public class product {
    private int pid;
    private String pname;
    private String pdescription;
    private int pprice;
    private int pdiscount;
    private int pquantity;
    private String pimage;
    private String catname;

    // Getters and Setters
    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getPdescription() {
        return pdescription;
    }

    public void setPdescription(String pdescription) {
        this.pdescription = pdescription;
    }

    public int getPprice() {
        return pprice;
    }

    public void setPprice(int pprice) {
        this.pprice = pprice;
    }

    public int getPdiscount() {
        return pdiscount;
    }

    public void setPdiscount(int pdiscount) {
        this.pdiscount = pdiscount;
    }

    public int getPquantity() {
        return pquantity;
    }

    public void setPquantity(int pquantity) {
        this.pquantity = pquantity;
    }

    public String getPimage() {
        return pimage;
    }

    public void setPimage(String pimage) {
        this.pimage = pimage;
    }

    public String getCatname() {
        return catname;
    }

    public void setCatname(String catname) {
        this.catname = catname;
    }
    //calculate price************************************(
    public int getPriceAfterDiscount() 
    {
        // Calculate the discount amount
        int discountAmount = (int) (this.getPprice() * (this.getPdiscount() / 100.0));
        // Return the price after subtracting the discount amount
        return this.getPprice() - discountAmount;
    }

    
}
