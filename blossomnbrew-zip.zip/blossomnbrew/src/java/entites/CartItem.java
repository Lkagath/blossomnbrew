package entites;

public class CartItem {
    private int itemId;
    private int quantity;
    private String pname;
    private String pdescription;
    private String pimage;
    private int pprice;
    private int productId;

    // Getters and Setters
    public int getItemId() { return itemId; }
    public void setItemId(int itemId) { this.itemId = itemId; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public String getPname() { return pname; }
    public void setPname(String pname) { this.pname = pname; }
    public String getPdescription() { return pdescription; }
    public void setPdescription(String pdescription) { this.pdescription = pdescription; }
    public String getPimage() { return pimage; }
    public void setPimage(String pimage) { this.pimage = pimage; }
    public double getPprice() { return pprice; }
    public void setPprice(int pprice) { this.pprice = pprice; }
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
}
