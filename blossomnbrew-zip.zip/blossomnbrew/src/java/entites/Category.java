package entites;

import java.util.ArrayList;
import java.util.List;

public class Category {
    private int cid;
    private String cname;
    private String cdes;
    private List<product> products = new ArrayList<>();

    // Constructor with parameters
    public Category(int cid, String cname, String cdes) {
        this.cid = cid;
        this.cname = cname;
        this.cdes = cdes;
    }

    // No-argument constructor
    public Category() {
        // Default constructor, no exception thrown
    }

    // Getters and setters
    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getCdes() {
        return cdes;
    }

    public void setCdes(String cdes) {
        this.cdes = cdes;
    }

    public List<product> getProducts() {
        return products;
    }

    public void setProducts(List<product> products) {
        this.products = products;
    }
}
