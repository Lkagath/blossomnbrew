package servlets;

import dao.productDao;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Update_Product_Servlet")
public class UpdateProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve updated product data from request
        int pid = Integer.parseInt(request.getParameter("pid"));
        String pname = request.getParameter("pname");
        String pdescription = request.getParameter("pdescription");
        int pprice = Integer.parseInt(request.getParameter("pprice"));
        int pdiscount = Integer.parseInt(request.getParameter("pdiscount"));
        int pquantity = Integer.parseInt(request.getParameter("pquantity"));

        // Create a ProductDAO object and update the product
        productDao productDAO = new productDao();
        boolean success = productDAO.updateProduct(pid, pname, pdescription, pprice, pdiscount, pquantity);
        
        // Set status message and redirect
        HttpSession session = request.getSession();
        if (success) {
            session.setAttribute("message4", "Product updated successfully.");
        } else {
            session.setAttribute("message4", "Error updating product.");
        }
        
        response.sendRedirect("update_product.jsp");
    }
}
