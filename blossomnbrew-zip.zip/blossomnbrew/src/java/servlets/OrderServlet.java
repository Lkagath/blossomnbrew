/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import dao.OrderDAO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import entites.Order;
@WebServlet("/OrderServlet")
public class OrderServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        try {
            
            String uname = request.getParameter("uname");
            String address = request.getParameter("address");
            String contact = request.getParameter("contact");
            Date orderDate = new Date(System.currentTimeMillis()); // current date
            String status = "Pending"; // default status
            String pname=request.getParameter("pname");
            String payment_method=request.getParameter("payment_method");
            String amount=request.getParameter("amount");
            
        // Debugging output (for checking variable values)
        

            


            OrderDAO orderDAO = new OrderDAO();
            boolean orderPlaced = orderDAO.placeOrder(uname, address, contact, orderDate, status, pname, payment_method, amount);

            
           if (orderPlaced)
           {
            response.sendRedirect("orderConfirmation.jsp");
            } 
           else
           {
            response.sendRedirect("error.jsp");
            }
        }
        catch (NumberFormatException e) 
        {
                         e.printStackTrace();
                     response.getWriter().println("Error occurred: Invalid PID value. " + e.getMessage());
          }
        catch (Exception e)
        {
           
             e.printStackTrace();
            response.getWriter().println("Error occurred to in order servlet: " + e.getMessage());
        }   
        

        
    }
}
