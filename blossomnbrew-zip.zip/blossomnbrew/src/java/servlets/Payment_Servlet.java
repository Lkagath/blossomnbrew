package servlets;

import dao.PaymentDAO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;


public class Payment_Servlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int orderId = Integer.parseInt(request.getParameter("orderId"));
        String paymentMethod = request.getParameter("paymentMethod");
        double amount = Double.parseDouble(request.getParameter("amount"));
        Date paymentDate = new Date(System.currentTimeMillis()); // current date
        String paymentStatus = "Pending"; // default status

        PaymentDAO paymentDAO = new PaymentDAO();
        boolean result = paymentDAO.processPayment(orderId, paymentMethod, (int) amount, paymentDate, paymentStatus);

        if (result) {
            response.getWriter().println("Payment submitted successfully!");
        } else {
            response.getWriter().println("Failed to submit payment.");
        }
    }
}
