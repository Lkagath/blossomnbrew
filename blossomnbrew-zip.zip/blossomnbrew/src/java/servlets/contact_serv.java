package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class contact_serv extends HttpServlet 
{

    protected void doPost(HttpServletRequest request, HttpServletResponse response)

            throws ServletException, IOException 
    {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter())
        {
            
                
                try
                {
                      Class.forName("com.mysql.jdbc.Driver");
                      Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/blossomnbrew","root","");
                      String sql="INSERT  INTO feedback (fname, femail, fmess) VALUES (?, ?, ?)";
                      PreparedStatement pst=con.prepareStatement(sql);
                    
                      String fname=request.getParameter("fname");
                      String femail=request.getParameter("femail");
                      String fmess=request.getParameter("fmess");
                
                      pst.setString(1, fname);
                      pst.setString(2, femail);
                      pst.setString(3, fmess);
                      
                pst.executeUpdate();
                int rowsAffected=pst.executeUpdate();
                if(rowsAffected>0)
                {
                    HttpSession httpSession=request.getSession();
                    httpSession.setAttribute("message","Feedback Sent!!!");
                    response.sendRedirect("contact.jsp");
                
                }
                else
                    
                {
                    HttpSession httpSession=request.getSession();
                    httpSession.setAttribute("message","Failed Try Again!!!");
                    response.sendRedirect("contact.jsp");
                
                  
                }
                
                pst.close();
                con.close();
               
                      
                }
                catch(Exception e)
                {
                    HttpSession httpSession=request.getSession();
                    httpSession.setAttribute("message","errorrr!!!"+e.getMessage());
                    response.sendRedirect("contact.jsp"); 
           
                }
        
        
        }
    }


}
