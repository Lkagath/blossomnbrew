package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;

public class login_serv extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           
           try{
               Class.forName("com.mysql.jdbc.Driver");
               Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/blossomnbrew","root","");
               String sql="SELECT uemail, upassword, userType from register1 WHERE uemail=? and upassword=?";
               PreparedStatement pst=con.prepareStatement(sql);
               
               String userEmail= request.getParameter("email");
               String userPassword= request.getParameter("password");
               
               pst.setString(1,userEmail);
               pst.setString(2,userPassword);
               ResultSet rs=pst.executeQuery();
               
               if(rs.next())
               {
                   String userType=rs.getString("userType");
                   
                   HttpSession httpSession=request.getSession();
                   
                   httpSession.setAttribute("email",userEmail);
                   httpSession.setAttribute("userType",userType);
                   httpSession.setAttribute("message","Login successfull!!!");
                   
                   if("admin".equalsIgnoreCase(userType))
                   {
                       response.sendRedirect("admin_log.jsp");
                   }
                   else
                   {
                       response.sendRedirect("index.jsp");
                 
                   }
                   
                 
               }
               else
               {
                 
                   HttpSession httpSession=request.getSession();
                   httpSession.setAttribute("message","Invalid Details!!!");
                   response.sendRedirect("login.jsp");
                   
               }
               pst.close();
               con.close();
               
           }
           catch(Exception e)
           {
                    HttpSession httpSession=request.getSession();
                    httpSession.setAttribute("message","error!!!");
                    response.sendRedirect("login.jsp");
           }
            
        }
    }


}
