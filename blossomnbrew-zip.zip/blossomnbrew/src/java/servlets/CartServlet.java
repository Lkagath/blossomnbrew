/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import entites.CartProduct;
// Product class to hold product details

public class CartServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get product details from the request
        int pid = Integer.parseInt(request.getParameter("pid"));
        String pname = request.getParameter("pname");
        String pimage = request.getParameter("pimage");
        int pprice = Integer.parseInt(request.getParameter("pprice"));
        
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        // Create a new product for the cart
        CartProduct cartProduct = new CartProduct(pid, pname, pimage, pprice, quantity);

        // Get the session
        HttpSession session = request.getSession();

        // Retrieve the cart from the session
        List<CartProduct> cart = (List<CartProduct>) session.getAttribute("cart");
        if (cart == null)
        {
            cart = new ArrayList<>();
        }

        // Check if the product is already in the cart
        boolean productExists = false;
        for (CartProduct p : cart)
        {
            if (p.getPid() == pid) 
            {
                p.setQuantity(p.getQuantity() + quantity); // Update quantity
                productExists = true;
                break;
            }
        }

        // If product doesn't exist, add it to the cart
        if (!productExists) 
        {
            cart.add(cartProduct);
        }

        // Save the cart back to the session
        session.setAttribute("cart", cart);

        // Redirect to the cart page or product list
        response.sendRedirect("shop.jsp");
    }
}
