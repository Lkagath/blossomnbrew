package servlets;

import dao.productDao;
import entites.product;
import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet("/Add_Product_Servlet")
@MultipartConfig // Allows for file uploads
public class AddProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String pname = request.getParameter("pname");
        String pdescription = request.getParameter("pdescription");
        int pprice = Integer.parseInt(request.getParameter("pprice"));
        int pdiscount = Integer.parseInt(request.getParameter("pdiscount"));
        int pquantity = Integer.parseInt(request.getParameter("pquantity"));
        String catname = request.getParameter("catname");
        
        // Handle product image upload
        Part part = request.getPart("pimage");
        String fileName = part.getSubmittedFileName();
       

      
        // Create a Product object and set values
        product Product = new product();
        Product.setPname(pname);
        Product.setPdescription(pdescription);
        Product.setPprice(pprice);
        Product.setPdiscount(pdiscount);
        Product.setPquantity(pquantity);
        Product.setCatname(catname); // Set category ID
        Product.setPimage(fileName); // Store the relative image path

        // Save product to the database using ProductDAO
        productDao productDAO = new productDao();
        boolean success = productDAO.addProduct(Product);

        // Set status message and redirect
        HttpSession session = request.getSession();
        if (success) {
            session.setAttribute("message6", "Product added successfully.");
        } else {
            session.setAttribute("message6", "Error adding product.");
        }

        response.sendRedirect("add_product.jsp");
        
        // other product data retrieval from the form
        
        
        
        // Check if product exists
      /*  if (productDAO.productExists(pname)) {
            // If the product exists, show an error message
            request.setAttribute("errorMessage", "Product with the same name already exists.");
            request.getRequestDispatcher("add_product.jsp").forward(request, response);
        } else {
            // Proceed with adding the product if it doesn't exist
            // your existing product insertion code
        }
    */
    }
    
}
