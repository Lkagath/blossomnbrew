package servlets;

import dao.productDao;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/DeleteProductServlet")
public class Delete_prod_serv extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get product ID from the request
        int pid = Integer.parseInt(request.getParameter("pid"));
        
        // Create a ProductDAO object
        productDao productDAO = new productDao();
        
        // Delete the product
        boolean success = productDAO.deleteProduct(pid);
        
        // Redirect with a status message
        HttpSession session = request.getSession();
        if (success)
        {
            session.setAttribute("message2", "Product deleted successfully.");
        }
        else
        {
            session.setAttribute("message3", "Error deleting product.");
        }
        
        response.sendRedirect("delete_product.jsp");
    }
}
