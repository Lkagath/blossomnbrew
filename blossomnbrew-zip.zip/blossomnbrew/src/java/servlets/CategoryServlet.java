import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.CatDao;
import entites.Category;

public class CategoryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        CatDao categoryDao = new CatDao();
        List<Category> categories = categoryDao.getAllCategories();
        
        // Set categories as a request attribute
        request.setAttribute("categories", categories);
        
        // Forward to the JSP page
        request.getRequestDispatcher("product2.jsp").forward(request, response);
    }
}
