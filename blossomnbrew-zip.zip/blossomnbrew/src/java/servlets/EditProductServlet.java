package servlets;

import dao.productDao;
import entites.product;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Edit_Product_Servlet")
public class EditProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve product ID from request
        int pid = Integer.parseInt(request.getParameter("pid"));
        
        // Fetch product data from the database
        productDao productDAO = new productDao();
        product Product = productDAO.getProductById(pid);
        
        // Forward the data to the edit_product.jsp page
        
        
        
        
        request.setAttribute("product", Product);
        request.getRequestDispatcher("edit_product.jsp").forward(request, response);
    }
}
