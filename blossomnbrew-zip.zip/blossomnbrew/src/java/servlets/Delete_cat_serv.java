package servlets;
import dao.CatDao;
import java.io.IOException;
import static java.lang.System.out;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/DeleteCategoryServlet")
public class Delete_cat_serv extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get category ID from the request
        int cid = Integer.parseInt(request.getParameter("cid"));
        
        // Create a CategoryDAO object
        CatDao categoryDAO = new CatDao();
        
        // Delete the category
        boolean success = categoryDAO.deleteCategory(cid);
        
         // Redirect with a status message
    HttpSession session = request.getSession();
    if (success)
    {
        session.setAttribute("message11", "Category deleted successfully.");
    }
    else
    {
        session.setAttribute("message11", "Error deleting category.");
    }
    
    response.sendRedirect("delete_category.jsp");
 }
}
