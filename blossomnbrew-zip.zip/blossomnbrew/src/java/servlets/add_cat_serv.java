package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.sql.*;
import javax.servlet.http.HttpSession;
@MultipartConfig
public class add_cat_serv extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            
             
               String operation=request.getParameter("operation");
               if(operation!=null&&operation.equals("addcategory"))
               {
                   String catTitle=request.getParameter("catTitle");
                   String catDec=request.getParameter("catDes");
                  
                   try{
                        Class.forName("com.mysql.jdbc.Driver");
                        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/blossomnbrew","root","");
                        String sql="INSERT INTO category1(cname, cdes) VALUES(?,?)";
                        PreparedStatement ps=con.prepareStatement(sql);
                        
                        ps.setString(1, catTitle);
                        ps.setString(2, catDec);
                        
                        
                        int rowInserted=ps.executeUpdate();
                        if(rowInserted>0)
                        {
                           
                            out.println("<h3>Category Added!!!</h3>");
                            out.println("<a href='admin_log.jsp'>Go back to Admin Panel</a>");
                         
                        }
                        else
                        {
                           out.println("<h3>Please try again!!!</h3>");
                           out.println("<a href='admin_log.jsp'>Go back to Admin Panel</a>");

                           
                        }
                   }
                   catch(Exception e)
                   {
                       out.println("<h3>error!!!</h3>");
                       out.println("<a href='admin_log.jsp'>Go back to Admin Panel</a>");
 
                   }
                   
               }
               else
               {
                  ////HttpSession httpSession=request.getSession();
                 // httpSession.setAttribute("message","Invalid Details!!!");
                   response.getWriter().println("invalid operation");
               }
            }
            
            
        }
    }



