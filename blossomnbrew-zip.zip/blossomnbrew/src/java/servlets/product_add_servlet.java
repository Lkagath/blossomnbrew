package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Arrays;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


public class product_add_servlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) 
        {
            // Print all parameters for debugging
        
            
            String operations = request.getParameter("operation3");
            out.println("<h2>Operation:</h2> " + operations);

            if ("proadd".equals(operations)) 
            {
                String pname = request.getParameter("pname");
                String pdescription = request.getParameter("pdescription");
                int pprice = Integer.parseInt(request.getParameter("pprice"));
                int pdiscount = Integer.parseInt(request.getParameter("pdiscount"));
                int pquantity = Integer.parseInt(request.getParameter("pquantity"));
                String catname = request.getParameter("catname");

                Part part = request.getPart("pimage");
                String imageName = part.getSubmittedFileName();
                String imagePath = getServletContext().getRealPath("/") + imageName;
                part.write(imagePath);

                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/blossomnbrew", "root", "");
                    String sql = "INSERT INTO product (pname, pdescription, pprice, pdiscount, pquantity, pimage) VALUES (?, ?, ?, ?, ?, ?)";
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.setString(1, pname);
                    ps.setString(2, pdescription);
                    ps.setInt(3, pprice);
                    ps.setInt(4, pdiscount);
                    ps.setInt(5, pquantity);
                    ps.setString(6, catname);
                    ps.setString(7, imageName);

                    int rowInserted = ps.executeUpdate();
                    if (rowInserted > 0)
                    {
                        out.println("Product added successfully.");
                    }
                    else 
                    {
                        out.println("Failed to add product.");
                    }
                } 
                catch (Exception e)
                {
                    e.printStackTrace(out);
                    out.println("Error: " + e.getMessage());
                }
            }
            else
            {
                out.println("Invalid operation - " + operations);
            }
        }
    }
}
