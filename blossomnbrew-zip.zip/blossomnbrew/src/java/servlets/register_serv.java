package servlets;

import entites.user;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.http.HttpSession;

public class register_serv extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            try{
             
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/blossomnbrew","root","");
                String sql="INSERT  INTO register1 (uname, uemail, upassword, umobile, uaddress, userType) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement pst=con.prepareStatement(sql);
                
                String userName= request.getParameter("user_name");
                String userEmail= request.getParameter("user_email");
                String userPassword= request.getParameter("user_password");
                String userPhone= request.getParameter("user_phone");
                String userAddress= request.getParameter("user-address");
                
                String userType=userEmail.equals("lily@gmail.com") ? "admin" : "user";
                
                pst.setString(1,userName);
                pst.setString(2,userEmail);
                pst.setString(3,userPassword);
                pst.setString(4,userPhone);
                pst.setString(5,userAddress);
                
                pst.setString(6,userType);
                
                pst.executeUpdate();
                int rowsAffected=pst.executeUpdate();
                if(rowsAffected>0)
                {
                    HttpSession httpSession=request.getSession();
                    httpSession.setAttribute("message","Registration successfull!!!");
                    response.sendRedirect("index.jsp");
                
                }
                else
                    
                {
                    HttpSession httpSession=request.getSession();
                    httpSession.setAttribute("message","Registration Failed!!!");
                    response.sendRedirect("register.jsp");
                }
                
                pst.close();
                con.close();
               
               // out.println("<h1>Successfully Saved!!!</h1>");
               
                
                /*//  validations
                if(userName.isEmpty())
                {
                    out.println("Please enter your name...");
                    return;
                }
                 if(userPassword.isEmpty())
                {
                    out.println("Please enter your Password...");
                    return;
                }
                 //creating user object to store data
                */
                //
            }
            catch(Exception e){
                    HttpSession httpSession=request.getSession();
                    httpSession.setAttribute("message","errorrr!!!"+e.getMessage());
                    response.sendRedirect("register.jsp");               
            }
        }
    }

 

}
