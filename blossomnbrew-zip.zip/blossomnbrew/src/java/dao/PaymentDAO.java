package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;

public class PaymentDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/blossomnbrew"; // update with your DB URL
    private String jdbcUsername = "root"; // update with your DB username
    private String jdbcPassword = ""; // update with your DB password

    private static final String INSERT_PAYMENT_SQL = "INSERT INTO payment (order_id, pay_method, amount, pay_date, pay_status) VALUES (?, ?, ?, ?, ?);";

    public boolean processPayment(int orderId, String paymentMethod, int amount, Date paymentDate, String paymentStatus) {
        boolean rowInserted = false;
        
        
        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_PAYMENT_SQL)) {
            preparedStatement.setInt(1, orderId);
            preparedStatement.setString(2, paymentMethod);
            preparedStatement.setInt(3, amount);
            preparedStatement.setDate(4, paymentDate);
            preparedStatement.setString(5, paymentStatus);

            rowInserted = preparedStatement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error inserting payment: " + e.getMessage());
        }
        return rowInserted;
    }
}
