/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entites.ConnectionManager;
import entites.user;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.jms.Session;

/**
 *
 * @author HP
 */
public class UserDao {
    /*public User getUserByEmailAndPassword()
    {
        
    }*/
    public user getUserByEmailAndPassword(String email,String password)
    {
        user User=null;
        try
        {
            String query="from register1 where uemail=: e and upassword=: p";
           
            if(User==null)
            {
              //  out.println("");
            }
            
        }
         catch(Exception e)
         {
        
          }
        return User;
    }
       public List<user> getAllUsers() {
        List<user> userList = new ArrayList<>();
        String query = "SELECT * FROM register1"; // Change 'users' to your actual user table name

        try (Connection connection=ConnectionManager.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                user user = new user();
                user.setUid(rs.getInt("uid")); // Assuming 'id' is the column name for user ID
                user.setUname(rs.getString("uname")); // Assuming 'username' is the column name
                user.setUemail(rs.getString("uemail")); // Assuming 'email' is the column name
                user.setUpassword(rs.getString("upassword")); // Assuming 'contact' is the column name
                user.setUmobile("umobile");
                user.setUaddress("uaddress");
                user.setUserType("userType");
                userList.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userList;
    }
    
}
