package dao;

import entites.CartItem;
import entites.ConnectionManager;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartDao {
    private Connection conn;

    public CartDao() {
        // Initialize your database connection here
       try
       {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/blossomnbrew","root","");
       }
       catch(Exception e)
       {
           
       }
    }

   public void addToCart(int userId, int productId, int quantity, double price) {
        String query = "INSERT INTO cart_items (user_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            pstmt.setInt(2, productId);
            pstmt.setInt(3, quantity);
            pstmt.setDouble(4, price);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<CartItem> getCartItems(int userId) {
        List<CartItem> items = new ArrayList<>();
        String query = "SELECT ci.quantity, p.pid, p.pname, p.pdescription, p.pimage, p.pprice "
                     + "FROM cart_items ci JOIN product p ON ci.product_id = p.pid "
                     + "WHERE ci.user_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                CartItem item = new CartItem();
                item.setProductId(rs.getInt("pid"));
                item.setPname(rs.getString("pname"));
                item.setPdescription(rs.getString("pdescription"));
                item.setPimage(rs.getString("pimage"));
                item.setPprice(rs.getInt("pprice"));
                item.setQuantity(rs.getInt("quantity"));
                items.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }
}
