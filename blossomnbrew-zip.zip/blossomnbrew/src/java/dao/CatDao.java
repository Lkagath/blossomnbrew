package dao;

import entites.Category;
import entites.ConnectionManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CatDao {

    // Method to retrieve all categories
    public List<Category> getAllCategories() 
    {
        List<Category> categoryList = new ArrayList<>();
        String query = "SELECT * FROM category1";
        
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) 
        {

            while (rs.next())
            {
                Category category = new Category();
                category.setCid(rs.getInt("cid"));  // Assuming catid is the column name in your table
                category.setCname(rs.getString("cname"));
                category.setCdes(rs.getString("cdes"));

                categoryList.add(category);
            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return categoryList;
    }

    // Method to delete a category by ID
    public boolean deleteCategory(int catid) {
        boolean rowDeleted = false;
        try (Connection conn = ConnectionManager.getConnection())
        {
            String query = "DELETE FROM category1 WHERE cid = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, catid);
            
            rowDeleted = stmt.executeUpdate() > 0;
        } 
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return rowDeleted;
    }
}
