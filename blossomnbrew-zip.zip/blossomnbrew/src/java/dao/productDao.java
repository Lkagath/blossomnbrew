package dao;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import entites.ConnectionManager;
import entites.product; // Adjust the package name accordingly
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class productDao
{
    
    public List<product> getAllProducts() {
        List<product> productList = new ArrayList<>();
       
       String query = "SELECT * FROM product";
        
        try (Connection connection = ConnectionManager.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) 
            {
                product Product = new product();
                Product.setPid(resultSet.getInt("pid"));
                Product.setPname(resultSet.getString("pname"));
                Product.setPdescription(resultSet.getString("pdescription"));
                Product.setPprice(resultSet.getInt("pprice"));
                Product.setPdiscount(resultSet.getInt("pdiscount"));
                Product.setPquantity(resultSet.getInt("pquantity"));
                Product.setPimage(resultSet.getString("pimage"));
                Product.setCatname(resultSet.getString("catname"));
                productList.add(Product);
            }

        } catch (SQLException e)
        {
            e.printStackTrace();
        }

        return productList;
    }
    public List<product> getProductsByCategory(String categoryName)
    {
    List<product> products = new ArrayList<>();
    
    String query1 = "SELECT * FROM product WHERE catname = ?";
    try (Connection connection = ConnectionManager.getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(query1)) {
        
        preparedStatement.setString(1, categoryName); // Set the category name parameter
        ResultSet resultSet = preparedStatement.executeQuery();
        
        while (resultSet.next()) {
            product product = new product();
            product.setPid(resultSet.getInt("pid")); // Assuming you have a pid field
            product.setPname(resultSet.getString("pname"));
            product.setPdescription(resultSet.getString("pdescription"));
            product.setPprice(resultSet.getInt("pprice"));
            product.setPdiscount(resultSet.getInt("pdiscount"));
            product.setPquantity(resultSet.getInt("pquantity"));
            product.setPimage(resultSet.getString("pimage"));
            product.setCatname(resultSet.getString("catname"));
            products.add(product);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return products;
    
}
     public boolean deleteProduct(int pid) {
        boolean rowDeleted = false;
        try (Connection conn = ConnectionManager.getConnection()) {
            String query = "DELETE FROM product WHERE pid = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, pid);

            rowDeleted = stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowDeleted;
    }
      public product getProductById(int pid) {
        product product = null;
        String query = "SELECT * FROM product WHERE pid = ?";
        
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, pid);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    product = new product();
                    product.setPid(rs.getInt("pid"));
                    product.setPname(rs.getString("pname"));
                    product.setPdescription(rs.getString("pdescription"));
                    product.setPprice(rs.getInt("pprice"));
                    product.setPdiscount(rs.getInt("pdiscount"));
                    product.setPquantity(rs.getInt("pquantity"));
                    product.setPimage(rs.getString("pimage"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return product;
    }

    // Method to update a product
    public boolean updateProduct(int pid, String pname, String pdescription, int pprice, int pdiscount, int pquantity) {
        boolean rowUpdated = false;
        String query = "UPDATE product SET pname = ?, pdescription = ?, pprice = ?, pdiscount = ?, pquantity = ? WHERE pid = ?";
        
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, pname);
            stmt.setString(2, pdescription);
            stmt.setInt(3, pprice);
            stmt.setInt(4, pdiscount);
            stmt.setInt(5, pquantity);
            stmt.setInt(6, pid);
            
            rowUpdated = stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowUpdated;
    }
     public boolean addProduct(product Product) {
        boolean rowInserted = false;
        String query = "INSERT INTO product (pname, pdescription, pprice, pdiscount, pquantity, pimage, catname) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, Product.getPname());
            stmt.setString(2, Product.getPdescription());
            stmt.setInt(3, Product.getPprice());
            stmt.setInt(4, Product.getPdiscount());
            stmt.setInt(5, Product.getPquantity());
            stmt.setString(6, Product.getPimage());
            stmt.setString(7, Product.getCatname());

            rowInserted = stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowInserted;
    }
      public boolean productExists(String pname) {
        boolean exists = false;
        String query = "SELECT COUNT(*) FROM product WHERE pname = ?";
        
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {
             
            ps.setString(1, pname);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                exists = rs.getInt(1) > 0; // If count > 0, product exists
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return exists;
    }

}
