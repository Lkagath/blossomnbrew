/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entites.Order;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.ResultSet;

public class OrderDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/blossomnbrew"; // update with your DB URL
    private String jdbcUsername = "root"; // update with your DB username
    private String jdbcPassword = ""; // update with your DB password

    private static final String INSERT_ORDER_SQL = "INSERT INTO orders (uname, address, contact, OrderDate, status, pname, payment_method, amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";

    public boolean placeOrder(String uname, String address, String contact, Date orderDate, String status, String pname, String payment_method, String amount) {
        boolean rowInserted = false;
        
        Order order = new Order();
    
    order.setUname(uname);
    order.setAddress(address);
    order.setContact(contact);
    order.setOrderDate(orderDate);
    order.setStatus(status);
    order.setPname(pname);
    order.setPayment_method(payment_method);
    order.setAmount(amount);
    
        
        
        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_ORDER_SQL)) {
            
           
            preparedStatement.setString(1, order.getUname());
            preparedStatement.setString(2, order.getAddress());
            preparedStatement.setString(3, order.getContact());
            preparedStatement.setDate(4, order.getOrderDate());
            preparedStatement.setString(5, order.getStatus());
            preparedStatement.setString(6, order.getPname());
            preparedStatement.setString(7, order.getPayment_method());
            preparedStatement.setString(8, order.getAmount());
            
            rowInserted = preparedStatement.executeUpdate() > 0;
        } 
        catch (SQLException e)
        {
           e.printStackTrace();
           System.out.println("Error inserting order: " + e.getMessage());
        }
        return rowInserted;
    }
   
}
